package mySystem;

import java.util.NavigableMap;
import java.util.Scanner;

import content.Content;
import content.Slide;
import ui.CLI;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		NavigableMap<String,Slide> oContent = Content.getContent();
		
		Scanner oScanner = new Scanner(System.in);
		
		CLI oCLI = CLI.getInstance();
		oCLI.init(oScanner);
		oCLI.init(oContent);
		
		oCLI.run();
		
	}

}
