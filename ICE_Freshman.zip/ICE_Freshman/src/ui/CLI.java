package ui;

import java.util.Map;
import java.util.NavigableMap;
import java.util.Scanner;

import content.Slide;

public class CLI {

	private static Scanner oReader;
	private static String sInput;
	private static String sWelcomeMsg;
	private static String sHelpMsg;
	private static String sUserName;
	
	private static String sCurrentPage = "";
	
	private static NavigableMap<String,Slide> oSlides;
	
	private CLI(){
		this.sUserName = "";
		this.sWelcomeMsg = "==< Welcome to ICE > ============================================\n";
		this.sWelcomeMsg += "Welcome to the Dept. of Information & Computer Engineering (ICE)!\n";
		this.sWelcomeMsg += "This is a brief intro to ICE. It's written in JAVA.\n";
		this.sWelcomeMsg += "Use your keyboard to navigate through this application.\n";
		this.sWelcomeMsg += "Enter 'help' for more information.\n";
		this.sWelcomeMsg += "We hope you like it. Let's get started.\n";
		this.sWelcomeMsg += "=================================================================\n";
		
		this.sHelpMsg = "==< Help >====================================\n";
		this.sHelpMsg += "Enter 'n' for next slide.\n";
		this.sHelpMsg += "Enter 'p' for previous slide.\n";
		//this.sHelpMsg += "Enter 'Go to pX' to go to page X.\n";
		this.sHelpMsg += "Enter 'Show index' to display the page index.\n";
		this.sHelpMsg += "Enter 'Quit' to terminate this application.\n";
		this.sHelpMsg += "==============================================\n";
	}

	private static class CLI_SingletonHelper{
		private static final CLI oInstance = new CLI();
	}//end CLI_SingletonHelper
	
	public static CLI getInstance(){
		return CLI_SingletonHelper.oInstance;
	}//end getInstance
	
	public void init(Scanner _oReader){
		oReader = _oReader;
	}//end init
	
	public void init(NavigableMap _oSlides){
		oSlides = _oSlides;
	}
	
	public void run(){
		print(sWelcomeMsg);
		
		if (sUserName.length()==0) {
			askUserName();
		} else {
			print("Hello, " + sUserName);
		}
		
		while (true){
			sInput = oReader.nextLine();
			if (sInput.equalsIgnoreCase("quit")){
				quit();
			}
			
			handleCommand(sInput);
			
		}//end while
	}//end run
	
	private void askUserName(){
		print("So, what is your name? (Type your name then hit the enter key.)");
		sUserName = oReader.nextLine();
			print("Hello, " + sUserName + "!");
			print(sHelpMsg);
		
	}//end askUserName
	
	private void handleCommand(String _sIn){

		switch (_sIn.toLowerCase()) {
		case "n":
			if (sCurrentPage.equalsIgnoreCase("")){
				print(oSlides.get(oSlides.firstKey()).getTitle());
				print(oSlides.get(oSlides.firstKey()).getContent());
				sCurrentPage = oSlides.firstKey();
				//print(sCurrentPage);
			} else if (oSlides.higherKey(sCurrentPage) != null){
				sCurrentPage = oSlides.higherKey(sCurrentPage);
				print(oSlides.get(sCurrentPage).getTitle());
				print(oSlides.get(sCurrentPage).getContent());
			} else if (oSlides.higherKey(sCurrentPage) == null){
				print("You're already at the last page.");
			}
			break;
		case "p":
			if (sCurrentPage.equalsIgnoreCase("")){
				print(oSlides.get(oSlides.firstKey()).getTitle());
				print(oSlides.get(oSlides.firstKey()).getContent());
				sCurrentPage = oSlides.firstKey();
			} else if (oSlides.lowerKey(sCurrentPage) != null){
				sCurrentPage = oSlides.lowerKey(sCurrentPage);
				print(oSlides.get(sCurrentPage).getTitle());
				print(oSlides.get(sCurrentPage).getContent());
			} else if (oSlides.lowerKey(sCurrentPage) == null){
				print("You're already at the first page.");
			}
			break;
		case "show index":
			for(Map.Entry<String,Slide> entry : oSlides.entrySet()) {
				  String sPage = entry.getKey();
				  String sTitle = entry.getValue().getTitle();
				  print(sPage + ": " + sTitle);
			}
			break;
		case "help":
			print(sHelpMsg);
			break;
		default:
			print("||Unrecognizable command.");
			print(sHelpMsg);
			break;
		} //end switch
		
	}
	
	private void print(String _sMsg){
		System.out.println(_sMsg);
	}//end Print
	
	private void quit(){
		print("bye");
		System.exit(0);
	}//end quit

}
