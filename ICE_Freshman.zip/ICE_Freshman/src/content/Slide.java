package content;

public class Slide {

	private String sTitle;
	private String sContent;
	
	public Slide(String _sTitle){
		this.sTitle = _sTitle;
	}
	
	public void setContent(String _sContent){
		this.sContent = _sContent;
	}
	
	public String getContent(){
		return this.sContent;
	}
	
	public String getTitle(){
		return this.sTitle;
	}
	
}
