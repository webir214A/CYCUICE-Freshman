package content;

import java.util.NavigableMap;
import java.util.TreeMap;

import content.Slide;

public class Content {
	private static NavigableMap<String,Slide> oContent = new TreeMap<String,Slide>();
	
	public static NavigableMap<String,Slide> getContent(){
		initSlides();
		return oContent;
	}
	
	private static void initSlides(){
		//Slide s = slideWhatYouCouldLearnAtICE()
		oContent.put("Page1", slideWhatYouCouldLearnAtICE());
		oContent.put("Page2", slidePhotos());
		oContent.put("Page3", slideGitHub());
		oContent.put("Page4", slideYourQuestions());
		oContent.put("Page5", slideFindUsOnMap());
	}
	
	private static Slide slideWhatYouCouldLearnAtICE(){
		Slide mySlide = new Slide("What You Could Learn at ICE");
		
		String sText = "";
		sText += "1. Software Programming\n";
		sText += " >> C, C++, JAVA, Python, SQL and so on...\n";
		sText += " >> OOP, Design Patterns, MVC...\n";
		sText += " >> Big Data, Cloud Computing, Web Apps...\n";
		sText += " >> Security, Multimedia...\n";
		sText += "\n";
		sText += "2. Hardware Programming\n";
		sText += " >> C, C++, JAVA, Python, SQL and so on...\n";
		sText += " >> Verilog, Assembly...\n";
		sText += " >> Embedded Systems, Communication, IC design...\n";
		sText += "\n";
		sText += "3. Fundamentals\n";
		sText += " >> Maths: Linear Algebra, Calculus, Statistics, Probability so on...\n";
		sText += " >> Electronics, Circuit, VLSI, so on...\n";
		sText += " >> English, English and English (3x cuz it's very important!)...\n";
		
		mySlide.setContent(sText);
		
		return mySlide;
	}//end slideWhatYouCouldLearnAtICE()

	private static Slide slidePhotos(){
		Slide mySlide = new Slide("Photos at ICE");
		String sText = "";
		sText += "1. ICE Photo Archives\n";
		sText += " >> https://get.google.com/albumarchive/103749106912181176599\n";
		sText += "2. ICE Final Year Projects\n";
		sText += " >> https://www.facebook.com/CYICEFresh/photos/?tab=album&album_id=1300081470019291\n";
		
		mySlide.setContent(sText);
		
		return mySlide;
	}//end slidePhotos()
	
	private static Slide slideGitHub(){
		Slide mySlide = new Slide("Contribute to This App");
		String sText = "";
		sText += "1. ICE Photo Archives\n";
		sText += " >> https://get.google.com/albumarchive/103749106912181176599\n";
		sText += "2. ICE Final Year Projects\n";
		sText += " >> https://www.facebook.com/CYICEFresh/photos/?tab=album&album_id=1300081470019291\n";
		
		mySlide.setContent(sText);
		
		return mySlide;
	}//end slideGitHub()
	
	private static Slide slideYourQuestions(){
		Slide mySlide = new Slide("Your Questions");
		String sText = "";
		sText += "1. Your First Questions...\n";
		sText += " >> ...\n";
		sText += "2. Your Second Questions...\n";
		sText += " >> ...\n";
		
		mySlide.setContent(sText);
		
		return mySlide;
	}//end slideYourQuestions()
	
	private static Slide slideFindUsOnMap(){
		Slide mySlide = new Slide("Find Us on Map");
		String sText = "https://www.pokemonradargo.com/\n";		
		mySlide.setContent(sText);
		
		return mySlide;
	}//end slideYourQuestions()
	
}
